import json

def load_json(path):
    with open(path, "r") as file:
        return json.load(file)

diseases = load_json("data/diseases.json")
vaccines = load_json("data/vaccinations.json")

def get_health_response(intent, message):
    message = message.lower()

    if intent == "disease_info":
        for key in diseases:
            if key in message:
                return diseases[key]
        return "Please consult a healthcare professional for accurate diagnosis."

    if intent == "vaccine_info":
        for key in vaccines:
            if key in message:
                return vaccines[key]
        return "Vaccinations are important. Visit the nearest health center."

    return "I can help you with disease symptoms, vaccinations, and health alerts."
