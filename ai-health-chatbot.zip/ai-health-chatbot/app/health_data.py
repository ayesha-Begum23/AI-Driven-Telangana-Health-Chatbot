import json

def load_data(path):
    with open(path, "r") as f:
        return json.load(f)

diseases = load_data("data/diseases.json")
vaccines = load_data("data/vaccinations.json")


def get_disease_info(msg):

    for k, v in diseases.items():
        if k in msg.lower():
            return v

    return "Consult a healthcare professional."


def get_vaccine_info(msg):

    for k, v in vaccines.items():
        if k in msg.lower():
            return v

    return "Visit nearest health center for vaccination."