from fastapi import FastAPI
from app.chatbot import process_message
from app.database import init_db

app = FastAPI()

init_db()

@app.get("/")
def home():
    return {"message": "Health Chatbot Running"}

@app.post("/chat")
def chat(message: str, language: str = "en", location: str = None):

    try:
        reply = process_message(message, language, location)
        return {"response": reply}

    except Exception as e:
        return {"response": f"Server Error: {str(e)}"}