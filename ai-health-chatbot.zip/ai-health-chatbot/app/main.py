from fastapi import FastAPI
from .chatbot import process_message
from .database import init_db

app = FastAPI(title="AI-Driven Public Health Chatbot")


@app.on_event("startup")
def startup_event():
    init_db()


@app.get("/")
def home():
    return {"status": "Health Chatbot is running"}


@app.post("/chat")
def chat(message: str, language: str = "en"):
    reply = process_message(message, language)
    return {"response": reply}
