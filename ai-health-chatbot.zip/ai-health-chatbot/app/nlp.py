def detect_intent(text: str) -> str:
    text = text.lower()

    if "fever" in text or "cough" in text or "symptom" in text:
        return "disease_info"

    if "vaccine" in text or "vaccination" in text:
        return "vaccine_info"

    if "alert" in text or "outbreak" in text:
        return "alert_info"

    return "general_info"
