def detect_intent(text):

    text = text.lower()

    if "fever" in text or "cough" in text:
        return "disease"

    if "vaccine" in text:
        return "vaccination"

    if "alert" in text or "outbreak" in text:
        return "alert"

    if "prevent" in text or "tip" in text:
        return "prevention"

    return "general"