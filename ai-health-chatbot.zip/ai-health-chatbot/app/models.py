class ChatRequest:
    def __init__(self, message: str, language: str = "en"):
        self.message = message
        self.language = language
