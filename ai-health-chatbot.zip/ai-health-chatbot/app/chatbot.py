from app.nlp import detect_intent
from app.health_data import get_disease_info, get_vaccine_info
from app.alerts import get_district_alert
from integrations.translation_service import translate_to_english, translate_to_user
from app.database import save_query


def process_message(message, language="en", location=None):

    try:
        print("\n--- NEW REQUEST ---")
        print("User Message:", message)
        print("Language:", language)
        print("Location:", location)

        # -------- TRANSLATE TO ENGLISH (SAFE) --------
        try:
            english = translate_to_english(message)
        except Exception as e:
            print("Translation Error:", e)
            english = message

        print("Translated Text:", english)

        # -------- DETECT INTENT --------
        intent = detect_intent(english)
        print("Detected Intent:", intent)

        # -------- RESPONSE LOGIC --------
        if intent == "alert":
            if location and location != "Select":
                response = get_district_alert(location)
            else:
                response = "Please select a district to view health alerts."

        elif intent == "disease":
            response = get_disease_info(english)

        elif intent == "vaccination":
            response = get_vaccine_info(english)

        elif intent == "prevention":
            response = "Maintain hygiene, wash hands regularly, drink clean water, and avoid crowded places."

        else:
            response = "I can help with disease symptoms, vaccines, and health alerts."

        print("Generated Response:", response)

        # -------- TRANSLATE BACK TO USER LANGUAGE --------
        try:
            translated = translate_to_user(response, language)
        except Exception as e:
            print("Reverse Translation Error:", e)
            translated = response

        print("Final Response:", translated)

        # -------- SAVE TO DATABASE --------
        try:
            save_query(message, translated)
        except Exception as e:
            print("Database Error:", e)

        return translated

    except Exception as e:
        print("CRITICAL ERROR:", e)
        return "⚠️ Server error occurred. Please try again."