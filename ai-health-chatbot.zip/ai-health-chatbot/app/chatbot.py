from app.nlp import detect_intent
from app.health_data import get_health_response
from app.alerts import get_alerts
from app.database import save_query

def process_message(message, language="en"):
    intent = detect_intent(message)

    if intent == "alert_info":
        response = get_alerts()
    else:
        response = get_health_response(intent, message)

    save_query(message, response)
    return response
