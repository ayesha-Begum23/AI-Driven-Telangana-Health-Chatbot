def get_alerts():
    return "Alert: Seasonal viral fever cases reported. Maintain hygiene and avoid crowded places."
