def get_district_alert(location):

    alerts = {
        "Hyderabad": "Dengue cases rising. Avoid stagnant water.",
        "Warangal": "Viral fever cases increasing.",
        "Karimnagar": "Water-borne diseases reported.",
        "Nizamabad": "Flu spread increasing.",
        "Khammam": "Malaria risk detected.",
        "Mahbubnagar": "Heatwave alert."
    }

    if location in alerts:
        return alerts[location]

    return "No major alerts."