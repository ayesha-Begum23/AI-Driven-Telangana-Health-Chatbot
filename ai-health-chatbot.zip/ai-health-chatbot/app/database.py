import sqlite3

conn = sqlite3.connect("database/health_chatbot.db", check_same_thread=False)
cursor = conn.cursor()

def init_db():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS queries(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        message TEXT,
        response TEXT
    )
    """)
    conn.commit()

def save_query(msg, res):
    cursor.execute(
        "INSERT INTO queries(message,response) VALUES(?,?)",
        (msg, res)
    )
    conn.commit()