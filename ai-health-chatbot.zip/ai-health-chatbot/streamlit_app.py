import streamlit as st
import requests
from datetime import datetime
import random

st.set_page_config(page_title="AI Driven Telangana Health Chatbot", page_icon="🏛️")

st.title("🏛️ AI Driven Telangana Public Health AI Chatbot")
st.caption("Department of Health & Family Welfare")

# Sidebar
language = st.sidebar.selectbox("Language", ["English", "Hindi", "Telugu"])

location = st.sidebar.selectbox(
    "Select District",
    ["Select", "Hyderabad", "Warangal", "Karimnagar", "Nizamabad", "Khammam", "Mahbubnagar"]
)

# Alerts
alerts = {
    "Hyderabad": "⚠️ Dengue cases rising",
    "Warangal": "⚠️ Viral fever outbreak",
    "Karimnagar": "⚠️ Water diseases",
    "Nizamabad": "⚠️ Flu spread",
    "Khammam": "⚠️ Malaria risk",
    "Mahbubnagar": "⚠️ Heatwave alert"
}

if location != "Select":
    st.sidebar.error(alerts.get(location))

# Tips
tips = [
    "Wash hands regularly",
    "Drink clean water",
    "Take vaccines on time"
]
st.sidebar.success(random.choice(tips))

# Chat history
if "chat" not in st.session_state:
    st.session_state.chat = []

msg = st.text_input("Ask your question")

if st.button("Send"):

    st.session_state.chat.append(("user", msg, datetime.now()))

    try:
        response = requests.post(
            "http://127.0.0.1:8000/chat",
            params={
                "message": msg,
                "language": language,
                "location": None if location == "Select" else location
            }
        )

        if response.status_code == 200:
            bot = response.json().get("response")
        else:
            bot = response.text

    except:
        bot = "Backend not running"

    st.session_state.chat.append(("bot", bot, datetime.now()))

# Display chat
for sender, text, time in st.session_state.chat:

    if sender == "user":
        st.markdown(f"👤 {text}")

    else:
        st.markdown(f"🤖 {text}")