import streamlit as st
import requests
from datetime import datetime
import random

# ------------------ PAGE CONFIG ------------------
st.set_page_config(
    page_title="AI Public Health Chatbot",
    page_icon="🩺",
    layout="centered"
)

# ------------------ STYLES ------------------
st.markdown("""
<style>
.chat-user {
    background-color: #DCF8C6;
    padding: 10px;
    border-radius: 10px;
    margin: 5px 0;
    text-align: right;
}
.chat-bot {
    background-color: #F1F0F0;
    padding: 10px;
    border-radius: 10px;
    margin: 5px 0;
}
.timestamp {
    font-size: 10px;
    color: gray;
}
</style>
""", unsafe_allow_html=True)

# ------------------ HEADER ------------------
st.title("🩺 AI-Driven Public Health Chatbot")
st.caption("Improving healthcare awareness in rural & semi-urban communities")

# ------------------ SIDEBAR ------------------
st.sidebar.header("⚙️ Settings")

language = st.sidebar.selectbox(
    "Language",
    ["english", "hindi", "tamil", "telugu"]
)

location = st.sidebar.selectbox(
    "Select Location",
    ["Select", "District A", "District B", "District C"]
)

st.sidebar.markdown("---")
st.sidebar.subheader("📢 Health Alert")
if location != "Select":
    st.sidebar.warning(
        f"⚠️ Alert in {location}: Seasonal viral fever cases reported. Maintain hygiene."
    )
else:
    st.sidebar.info("Select a location to view alerts")

# ------------------ HEALTH TIPS ------------------
st.sidebar.markdown("---")
st.sidebar.subheader("💡 Daily Health Tip")

health_tips = [
    "Wash your hands regularly with soap.",
    "Drink clean and boiled water.",
    "Complete all vaccination doses.",
    "Wear a mask in crowded places.",
    "Consult a doctor if fever lasts more than 2 days."
]

st.sidebar.success(random.choice(health_tips))

# ------------------ SESSION STATE ------------------
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# ------------------ CHAT INPUT ------------------
user_message = st.text_input("💬 Ask your health question:")

col1, col2 = st.columns(2)

with col1:
    send = st.button("📨 Send")

with col2:
    clear = st.button("🧹 Clear Chat")

if clear:
    st.session_state.chat_history = []

# ------------------ CHAT PROCESS ------------------
if send and user_message.strip():
    st.session_state.chat_history.append(
        ("user", user_message, datetime.now())
    )

    try:
        response = requests.post(
            "http://127.0.0.1:8000/chat",
            params={
                "message": user_message,
                "language": language
            }
        )
        bot_reply = response.json()["response"]
    except:
        bot_reply = "⚠️ Backend server is not running."

    st.session_state.chat_history.append(
        ("bot", bot_reply, datetime.now())
    )

# ------------------ DISPLAY CHAT ------------------
for sender, msg, time in st.session_state.chat_history:
    if sender == "user":
        st.markdown(
            f"""
            <div class="chat-user">
                {msg}
                <div class="timestamp">{time.strftime('%H:%M')}</div>
            </div>
            """,
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            f"""
            <div class="chat-bot">
                🤖 {msg}
                <div class="timestamp">{time.strftime('%H:%M')}</div>
            </div>
            """,
            unsafe_allow_html=True
        )

# ------------------ FOOTER ------------------
st.markdown("---")
st.caption(
    "⚠️ This chatbot provides health awareness information only and does not replace professional medical advice."
)
