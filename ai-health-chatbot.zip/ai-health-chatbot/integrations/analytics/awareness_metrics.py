def awareness_improvement(before,after):

    if before == 0:
        return 0

    return ((after-before)/before)*100