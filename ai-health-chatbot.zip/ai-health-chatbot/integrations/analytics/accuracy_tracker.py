from app.database import cursor

def calculate_accuracy():

    cursor.execute("SELECT COUNT(*) FROM feedback")
    total = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM feedback WHERE correct=1")
    correct = cursor.fetchone()[0]

    if total == 0:
        return 0

    return (correct/total)*100