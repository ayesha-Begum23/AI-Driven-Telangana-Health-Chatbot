import requests

def get_outbreak_data():

    try:
        data = requests.get(
            "https://disease.sh/v3/covid-19/all"
        ).json()

        return f"Global cases today: {data['todayCases']}"

    except:
        return "No outbreak data available."